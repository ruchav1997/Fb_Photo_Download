<?php
session_start();
require_once __DIR__ . '/src/Facebook/autoload.php';
$album_id = isset($_POST['album_id']) ? $_POST['album_id'] : die('Album ID not specified.');
$album_name = isset($_POST['album_name']) ? $_POST['album_name'] : die('Album name not specified.');
$access_token=$_SESSION['facebook_access_token'];
$fields="album,likes,comments";
$fb_page_id = $_SESSION['id_user'];
$graphPhoLink = "https://graph.facebook.com/v2.9/{$album_id}/photos?fields=source,images,name&access_token={$access_token}";
$jsonData = file_get_contents($graphPhoLink);
$fbPhotoObj = json_decode($jsonData, true, 512, JSON_BIGINT_AS_STRING);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<?php
if(isset($_POST['download']))
{
	echo $_POST['hphoto'];
	$fbPhotoData = $fbPhotoObj['data'];
	$count = 0;
	foreach($fbPhotoData as $data){
	    $count++;
		$imageData = end($data['images']);
	    $imgSource = isset($imageData['source'])?$imageData['source']:'';
	    $name = isset($data['name'])?$data['name']:'';
	  
	    $content = file_get_contents($imgSource);
		if($_POST['hphoto'] == $count)
		{
			//$name,$imgSource
			$content = file_get_contents($imgSource);
			//Store in the filesystem.
			$n = rand(10,100000);
			$fp = fopen("save/$n.jpg", "w");
			fwrite($fp, $content);
			fclose($fp);
			header('Location:photos.php?album_id='.$album_id.'&album_name='.$album_name.'');
			break;
		}

	}
	
}

if(isset($_POST['zip']))
{
	$a=array("red","green");
	array_push($a,"blue","yellow");
	echo 'in zip code if';
	$fbPhotoData = $fbPhotoObj['data'];
	$cntent = array();
	foreach($fbPhotoData as $data){
	    $count++;
		$imageData = end($data['images']);
	    $imgSource = isset($imageData['source'])?$imageData['source']:'';
	    $name = isset($data['name'])?$data['name']:'';
	    
	    array_push($cntent,$imgSource);
	}
	
		$n = rand(10,100000);
		$zipname = $n.'.zip';
		$zip = new ZipArchive;
		$zip->open($zipname, ZipArchive::CREATE);
		foreach ($cntent as $file) 
		{
		  $zip->addFile($file);
		}
		$zip->close();
		header('Content-Type: application/zip');
		header('Content-disposition: attachment; filename='.$zipname);
		header('Content-Length: ' . filesize($zipname));
		readfile($zipname);
	header('Location:photos.php?album_id='.$album_id.'&album_name='.$album_name.'');
}


?>
<body>
</body>
</html>

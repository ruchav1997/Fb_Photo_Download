<?php

require_once __DIR__ . '/src/Facebook/autoload.php';

echo 'version is '.phpversion();


$fb = new Facebook\Facebook([
  'app_id' => '780601208779558',
  'app_secret' => '5b71b7594f79957c09674b45fefbabcb',
  'default_graph_version' => 'v2.8',
  ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email']; // optional
$permissions = ['user_photos']; // optional

//$fb = facebook_client();
// Get their albums
$accessToken = $helper->getAccessToken();
$albums = $fb->get('$accessToken','/me/albums');
// Loop their albums
foreach ($albums['data'] as $album) {
    $album = (object)$album;
    //fetch the images
    $album->images = array();
    $images = $fb->get('/'. $album->id .'/photos?limit=25');
    foreach ($images['data'] as $image) {
      $image = (object)$image;
      // Do something with the image ....
    }
    // Do something with the album ....
  }
  
  ?>
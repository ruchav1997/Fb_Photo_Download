<?php

session_start();
require_once __DIR__ . '/src/Facebook/autoload.php';

$album_id = isset($_GET['album_id']) ? $_GET['album_id'] : die('Album ID not specified.');
$album_name = isset($_GET['album_name']) ? $_GET['album_name'] : die('Album name not specified.');

$page_title = "{$album_name} Photos";
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title><?php echo $page_title; ?></title>
 
   
 
</head>
<body>
 
<div class="container" style="" >
<table>
 <?php
 
 $access_token=$_SESSION['facebook_access_token'];
//echo $access_token;
 
$fields="album,likes,comments";
$fb_page_id = $_SESSION['id_user'];
 

// Get photos of Facebook page album using Facebook Graph API
$graphPhoLink = "https://graph.facebook.com/v2.9/{$album_id}/photos?fields=source,images,name&access_token={$access_token}";
$jsonData = file_get_contents($graphPhoLink);
$fbPhotoObj = json_decode($jsonData, true, 512, JSON_BIGINT_AS_STRING);

$fbPhotoData = $fbPhotoObj['data'];
$count = 0;
foreach($fbPhotoData as $data){
	$count++;
    $imageData = end($data['images']);
    $imgSource = isset($imageData['source'])?$imageData['source']:'';
    $name = isset($data['name'])?$data['name']:'';
    
    echo '<div style="border-style: outset;height:300px; width:500px; padding-bottom:50px" align="center" > ';
    echo "<img src='{$imgSource}' alt=''>";
    $content = file_get_contents($imgSource);
	echo "<h3>{$name}</h3>";
	?>
		<form action="download.php" method="post">
			<input type="submit" name="download" value="DOWNLOAD" /><br/>
			<input type="hidden" name="hphoto" value="<?php echo $count;?>" />
			<input type="hidden" name="album_id" value="<?php echo $album_id;?>" />
			<input type="hidden" name="album_name" value="<?php echo $album_name;?>" />
		</form>
<?php
	echo "</div>";
   }
?>
</div>
<br><br>
 <form action="download.php" method="post">
 	<input type="submit" name="zip" value="DOWNLOAD ALL PHOTO IN ZIP"/>
	<input type="hidden" name="album_id" value="<?php echo $album_id;?>" />
	<input type="hidden" name="album_name" value="<?php echo $album_name;?>" />
 </form>
  <form action="download.php" method="post">
 	<input type="submit" name="google" value="UPLOAD ALL PHOTO IN GOOGLE DRIVE"/>
	<input type="hidden" name="album_id" value="<?php echo $album_id;?>" />
	<input type="hidden" name="album_name" value="<?php echo $album_name;?>" />
 </form>
</body>
</html>
